document.getElementById('Conctenations').onclick = function () {
    alert('Concatenations')
    document.getElementById('statment').innerHTML = 'let firstName = "Tayyab" <br> let lastName = "Ali" <br> fullname = firstName + " " + lastName '
    document.getElementById('output').innerHTML = 'Tayyab Ali'
}

document.getElementById('ask-name-from-user').onclick = function () {
   let fname = prompt ('Enter your first name')
   let lname = prompt ('Enter your last name')


   document.getElementById('statment').innerHTML= 'let fname = promt ("Enter your first name") <br> let fname = promt ("Enter your last name")'

   document.getElementById('output').innerHTML = fname + ' ' + lname
}

document.getElementById('comparison-oprator').onclick = function () {

    alert('Comparison-oprator')


   document.getElementById('statment').innerHTML= '== <br> === <br> != <br> !=='

   
}

document.getElementById('if-else-if').onclick = function () {

    alert('if-else-if')


   document.getElementById('statment').innerHTML= 'The if-else-if statement is used when we need to check multiple conditions. There s no need to check each condition separately; all conditions can be written in a sequence.'

   
}
document.getElementById('if-else-if').onclick = function () {

    alert('conditions')


   document.getElementById('statment').innerHTML= 'let marks = 85;if (marks >= 90) {  console.log("A+ Grade");} else if (marks >= 80) {console.log("A Grade");} else if (marks >70{ console.log("B Grade");} else { console.log("Fail");'

   
}
document.getElementById('testing-condition').onclick = function () {

    let age =prompt('enter your age') ;
    let weight =prompt('enter your weight') ;


   if(age >= 18 && weight <=70){
    alert('you are handsome man')
   }else if( age >= 18 && weight > 70){
     alert("your lessy guy")
   }else{
    alert('you are baby')
   }


   
}

document.getElementById('nestedIf').addEventListener('click',function(){
    let age = prompt('please enter your age')

    if(age >= 18){

        let weight = prompt('please enter your weight')       
        if(weight <=70){
         alert('your smart man')
        }else{
            alert('your fat guy!')
        }
    }
})

function login() {
    let userName = prompt('Enter your name')
    let password = prompt('Enter your password')
    if (userName === 'tayyab' && password ===123) {
        alert('login successfuly')
    }else{
      alert('login unsuccessfully')
    }
}

document.getElementById('clear-st').onclick= function(){
    document.getElementById('statment').innerHTML=''
}
document.getElementById('clear-output').onclick= function(){
    document.getElementById('output').innerHTML=''
}















// document.getElementById('Conctenations').onclick = function () {
//         document.getElementById('statment').innerHTML='let fname = "Tayyab" <br> let lname = "Ali" <br> let fullname = fname + lname'
//         document.getElementById('output').innerHTML = 'Tayyab Ali'
// }

// document.getElementById('ask-name-from-user').onclick = function () {
//     let fname = prompt('Enter your first name')
//     let lname = prompt('Enter your first name')
//     let fullname = fname +' '+ lname
//         document.getElementById('output').innerHTML = fullname
// }

// document.getElementById('comparison-oprator').onclick = function () {

//          alert('comparison-oprator')
//         document.getElementById('statment').innerHTML = '== <br> != <br> === <br> !== '
// }

// document.getElementById('if-else-if').onclick = function () {
//          alert('if-else-if')
//         document.getElementById('statment').innerHTML = 'The if-else-if statement is used when we need to check multiple conditions. There s no need to check each condition separately; all conditions can be written in a sequence'
// }

// document.getElementById('testing-condition').onclick = function () {
//         let age = prompt('enter your age')
//         let weight = prompt('enter your weight')
        
//         if (age >=18 && weight <=70) {
//                 alert('Your smart man')
//         }else if( age > 18 && weight > 70 ){
//                 alert('yor lesy guy')
//             }
//             else{
//                     alert('your are baby')
//                 }
                
//         }
        
//         document.getElementById('nestedIf').onclick = function () {
//         let age = prompt('enter your age')
//         if (age >= 18) {
//                 let weight = prompt('enter your weight')
//                 if (weight <=70) {
//                      alert('yor are smart man')   
//                 }else {
//                         alert('your fat guy')
//                 }
//         }
        
// }

// function login() {
//         let name = prompt('enter your name')
//         let password = prompt('enter your password')

//         if (name === 'tayyab' && password == 123456) {
//                 alert('login successfully')
//         }else{
//                 alert('unsuccessfully')
//         }
// }


